const { buildModule } = require("@nomicfoundation/hardhat-ignition/modules");

/**
 * This is the first module that will be run. It deploys the proxy and the
 * proxy admin, and returns them so that they can be used by other modules.
 */
const deploymentModule = buildModule("ProxyModule", (m) => {


    // This is our contract that will be proxied.
    // We will upgrade this contract with a new version later.
    const erc721Ai = m.contract("ERC721Ai");
    console.log("ERC721Ai", erc721Ai);
    return { erc721Ai };


});

module.exports = deploymentModule;