import hre from "hardhat";
import * as dotenv from "dotenv";
dotenv.config({ path: __dirname + "/.env" });
async function main() {
    const ERC721Ai = await hre.ethers.getContractFactory("ERC721Ai");
    console.log("ERC721Ai", ERC721Ai);
    const erc721Ai = await ERC721Ai.deploy();
    // await erc721Ai.waitForDeployment();
    // console.log("ERC721Ai deployed to:", erc721Ai.target);
}
main();